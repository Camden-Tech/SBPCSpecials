package me.BaddCamden.SBPCSpecials;

public enum TriggerType {
    ENTITY_DEATH,
    ENTITY_PICKUP,
    UNLOCK_ENTRY
}
