package me.BaddCamden.SBPCSpecials;

public interface SpecialHandler {
    void onSpecialTriggered(SpecialTriggeredEvent event);
}
